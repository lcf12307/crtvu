CREATE VIEW `vw_schedule` AS
  SELECT
    `crtvu`.`tb_arrangement`.`open_id`    AS `open_id`,
    `crtvu`.`tb_arrangement`.`id`         AS `id`,
    `crtvu`.`tb_arrangement`.`teacher_id` AS `teacher_id`,
    `crtvu`.`tb_arrangement`.`classroom`  AS `classroom`,
    `crtvu`.`tb_arrangement`.`class_name` AS `class_name`,
    `crtvu`.`tb_arrangement`.`day`        AS `day`,
    `crtvu`.`tb_arrangement`.`start_week` AS `start_week`,
    `crtvu`.`tb_arrangement`.`end_week`   AS `end_week`,
    `crtvu`.`tb_arrangement`.`start_time` AS `start_time`,
    `crtvu`.`tb_arrangement`.`end_time`   AS `end_time`,
    `vw_open`.`course_id`                 AS `course_id`,
    `vw_open`.`school_year`               AS `school_year`,
    `vw_open`.`term`                      AS `term`,
    `vw_open`.`people_num`                AS `people_num`,
    `vw_open`.`start_select_time`         AS `start_select_time`,
    `vw_open`.`end_select_time`           AS `end_select_time`,
    `vw_open`.`course_name`               AS `course_name`,
    `vw_open`.`credit`                    AS `credit`,
    `vw_open`.`nature`                    AS `nature`,
    `vw_open`.`department`                AS `department`
  FROM (`crtvu`.`tb_arrangement`
    JOIN `crtvu`.`vw_open` ON ((`crtvu`.`tb_arrangement`.`open_id` = `vw_open`.`open_id`)))